#include "stdio.h"
#include "stdlib.h"
#include "platform.h"
#include "sleep.h"
#include "xparameters.h"
#include "xil_printf.h"
#include "xil_cache.h"
#include "xil_io.h"
#include "xsdps.h"
#include "ff.h"
#include "PmodGPS.h"

#include "PmodAQS.h"

#include "PmodTMP3.h"

#include "PmodDPG1.h"

#include "PmodACL.h"

#define PERIPHERAL_CLK 100000000	// CLK definition for the GPS

void GPS_Initialize ();
void Get_GPS (char GPS_data[]);

PmodGPS GPS;
PmodAQS AQS;
PmodTMP3 TMP;
PmodDPG1 DPG;
PmodACL acl;

#define MAX 100
#define KPA   DPG1_KPA_PRESSURE_TYPE
#define ATM   DPG1_ATM_PRESSURE_TYPE
#define PSI   DPG1_PSI_PRESSURE_TYPE
#define INH2O DPG1_INH2O_PRESSURE_TYPE
#define CMH2O DPG1_CMH2O_PRESSURE_TYPE
#define MMHG  DPG1_MMHG_PRESSURE_TYPE

/************ SD card parameters ************/
static FATFS FS_instance;			// File System instance
static FIL file1;					// File instance
FRESULT result;						// FRESULT variable
char FileName[32];					// File name
static char *Log_File; 				// pointer to the log
static const char *Path = "0:/";	//  string pointer to the logical drive number
unsigned int BytesWr;				// Bytes written
int j = 0;							// file name index
/************ SD card parameters ************/

uint gpssize = 0;
char GPS_data[] = "<GPS did not get a ping...>";

int main()
{
    init_platform();

	GPS_Initialize ();

	result = f_mount(&FS_instance,Path, 1);

	double temp  = 0.0;
	double temp2 = 0.0;
	double temp3 = 0.0;
	float x, y, z;

	for (int j = 0; j < 100000000000000000; j++)
	{
		u8 buf[5];
		u16 eCO2;
		u16 TVOC;
		char indent[] = " \n";
		char dec[] = ".";
	    sprintf(FileName, "File_%d.TXT",j);
		Log_File = (char *)FileName;
		result = f_open(&file1, Log_File, FA_CREATE_ALWAYS | FA_WRITE );

		Get_GPS(GPS_data);
		AQS_GetData(&AQS, buf);
		////////////Number of Sats///////////////////////////////////////////
	    if (GPS.ping) {
	       GPS_formatSentence(&GPS);
	       if (GPS_isFixed(&GPS)) {
	   		int num = GPS_getNumSats(&GPS);
	   		char snum[5];
	   		// convert 123 to string [buf]
	   		itoa(num, snum, 10);
	   		// print our string
	   	    char destination[] = "Satillites = ";
	   	    strcat(destination,snum);
	   	    strcat(destination,indent);

	   		gpssize = strlen(destination);
	   		result = f_write(&file1, (const void*)destination, gpssize, &BytesWr);
	   		xil_printf("Data: %s\n", destination);

	   		char destinationlat[] = "Latitude: ";
	   		strcat(destinationlat,GPS_getLatitude(&GPS));
	   		strcat(destinationlat,indent);
	   		gpssize = strlen(destinationlat);
	   		result = f_write(&file1, (const void*)destinationlat, gpssize, &BytesWr);
	   		xil_printf("Data: %s\n", destinationlat);

	   		char destinationlong[] = "Longitude: ";
	   		strcat(destinationlong,GPS_getLongitude(&GPS));
	   		strcat(destinationlong,indent);
	   		gpssize = strlen(destinationlong);
	   		result = f_write(&file1, (const void*)destinationlong, gpssize, &BytesWr);
	   		xil_printf("Data: %s\n", destinationlong);

	   		char destinationatt[] = "Altitude: ";
	   		strcat(destinationatt,GPS_getAltitudeString(&GPS));
	   		strcat(destinationatt,indent);
	   		gpssize = strlen(destinationatt);
	   		result = f_write(&file1, (const void*)destinationatt, gpssize, &BytesWr);
	   		xil_printf("Data: %s\n", destinationatt);


	       } else {
	   		int num = GPS_getNumSats(&GPS);
	   		char snum[5];
	   		// convert 123 to string [buf]
	   		itoa(num, snum, 10);
	   		// print our string
	   	    char destination[] = "Satillites = ";
	   	    strcat(destination,snum);
	   	    strcat(destination,indent);

	   		gpssize = strlen(destination);
	   		result = f_write(&file1, (const void*)destination, gpssize, &BytesWr);
	   		xil_printf("Data: %s\n", destination);
	       }
	       GPS.ping = FALSE;
	    }






		int num = GPS_getNumSats(&GPS);
		char snum[5];
		// convert 123 to string [buf]
		itoa(num, snum, 10);
		// print our string
	    char destination[] = "Satillites = ";
	    strcat(destination,snum);
	    strcat(destination,indent);

		gpssize = strlen(destination);
		result = f_write(&file1, (const void*)destination, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destination);
	    //////////////////////////////////////////////////////////////////////////
	    ////////////AQS data///////////////////////////////////////////
        eCO2 = ((u16)buf[0] << 8) | ((u16)buf[1]);
   		TVOC = ((u16)buf[2] << 8) | ((u16)buf[3]);
		int numAQS = eCO2;
		char snumAQS[5];
		itoa(numAQS, snumAQS, 10);
	    char destinationAQS[] = "CO2 data = ";
	    char ppm[] = " ppm";
	    strcat(destinationAQS,snumAQS);
	    strcat(destinationAQS,ppm);
	    strcat(destinationAQS,indent);

		gpssize = strlen(destinationAQS);
		result = f_write(&file1, (const void*)destinationAQS, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationAQS);

		int numAQSV = TVOC;
		char snumAQSV[5];
		itoa(numAQSV, snumAQSV, 10);
	    char destinationAQSV[] = "VOTC data = ";
	    char ppb[] = " ppb";
	    strcat(destinationAQSV,snumAQSV);
	    strcat(destinationAQSV,ppb);
	    strcat(destinationAQSV,indent);

		gpssize = strlen(destinationAQSV);
		result = f_write(&file1, (const void*)destinationAQSV, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationAQSV);

		////////////TMP data///////////////////////////////////////////
	      temp  = TMP3_getTemp(&TMP);
	      temp2 = TMP3_CtoF(temp);
	      temp3 = TMP3_FtoC(temp2);
	      int temp2_round = 0;
	      int temp2_int   = 0;
	      int temp2_frac  = 0;
	      if (temp2 < 0) {
	         temp2_round = (int) (temp2 * 1000 - 5) / 10;
	         temp2_frac  = -temp2_round % 100;
	      } else {
	         temp2_round = (int) (temp2 * 1000 + 5) / 10;
	         temp2_frac  = temp2_round % 100;
	      }
	      temp2_int = temp2_round / 100;

	      int temp3_round = 0;
	      int temp3_int   = 0;
	      int temp3_frac  = 0;
	      if (temp3 < 0) {
	         temp3_round = (int) (temp3 * 1000 - 5) / 10;
	         temp3_frac  = -temp3_round % 100;
	      } else {
	         temp3_round = (int) (temp3 * 1000 + 5) / 10;
	         temp3_frac  = temp3_round % 100;
	      }
	      temp3_int = temp3_round / 100;

		char snumtempFwhole[5];
		itoa(temp2_int, snumtempFwhole, 10);
		char destinationTF[] = "Temperature: ";
		char F[] = " F";
		char snumtempFdec[5];
		itoa(temp2_frac, snumtempFdec, 10);
		strcat(destinationTF,snumtempFwhole);
		strcat(destinationTF,dec);
		strcat(destinationTF,snumtempFdec);
		strcat(destinationTF,F);
		strcat(destinationTF,indent);
		gpssize = strlen(destinationTF);
		result = f_write(&file1, (const void*)destinationTF, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationTF);



		char snumtempCwhole[5];
		itoa(temp3_int, snumtempCwhole, 10);
		char destinationTC[] = "Temperature: ";
		char C[] = " C";
		char snumtempCdec[5];
		itoa(temp3_frac, snumtempCdec, 10);
		strcat(destinationTC,snumtempCwhole);
		strcat(destinationTC,dec);
		strcat(destinationTC,snumtempCdec);
		strcat(destinationTC,C);
		strcat(destinationTC,indent);
		gpssize = strlen(destinationTC);
		result = f_write(&file1, (const void*)destinationTC, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationTC);



		////////////ACL data///////////////////////////////////////////
		ACL_ReadAccelG(&acl, &x, &y, &z);
		char ACLX[MAX];
		gcvt(x,6,ACLX);
		char destinationACLX[] = "ACL X: ";
		strcat(destinationACLX,ACLX);
		strcat(destinationACLX,indent);
		gpssize = strlen(destinationACLX);
		result = f_write(&file1, (const void*)destinationACLX, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationACLX);

		char ACLY[MAX];
		gcvt(y,6,ACLY);
		char destinationACLY[] = "ACL Y: ";
		strcat(destinationACLY,ACLY);
		strcat(destinationACLY,indent);
		gpssize = strlen(destinationACLY);
		result = f_write(&file1, (const void*)destinationACLY, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationACLY);

		char ACLZ[MAX];
		gcvt(z,6,ACLZ);
		char destinationACLZ[] = "ACL Z: ";
		strcat(destinationACLZ,ACLZ);
		strcat(destinationACLZ,indent);
		gpssize = strlen(destinationACLZ);
		result = f_write(&file1, (const void*)destinationACLZ, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationACLZ);


		////////////DPG data///////////////////////////////////////////
	    int rawData;
	    double pressureValue;
	    DPG1_readData(&DPG);

	    // Read raw data from PmodDPG1 and print it
	    rawData = (int) DPG.data;

	    int whole; // Used to get the whole number for the float
	    int not_whole;// Used to get the non whole number for the float

	    pressureValue = DPG1_GetPressure(KPA, &DPG);
	    whole = pressureValue; // Get whole number part of the physical value
	    not_whole = (pressureValue - whole) * 1000000; // Get fractional part

		char snumdpgKPAwhole[5];
		itoa(whole, snumdpgKPAwhole, 10);
		char destinationKPA[] = "Pressure: ";
		char KP[] = " KPA";
		char snumdpgKPAdec[5];
		itoa(not_whole, snumdpgKPAdec, 10);
		strcat(destinationKPA,snumdpgKPAwhole);
		strcat(destinationKPA,dec);
		strcat(destinationKPA,snumdpgKPAdec);
		strcat(destinationKPA,KP);
		strcat(destinationKPA,indent);
		gpssize = strlen(destinationKPA);
		result = f_write(&file1, (const void*)destinationKPA, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationKPA);


	    // Convert raw data into units of atm and print it
	    pressureValue = DPG1_GetPressure(ATM, &DPG);
	    whole = pressureValue;
	    not_whole = (pressureValue - whole) * 1000000;

		char snumdpgatmwhole[5];
		itoa(whole, snumdpgatmwhole, 10);
		char destinationATM[] = "Pressure: ";
		char atm[] = " ATM";
		char snumdpgatmdec[5];
		itoa(not_whole, snumdpgatmdec, 10);
		strcat(destinationATM,snumdpgatmwhole);
		strcat(destinationATM,dec);
		strcat(destinationATM,snumdpgatmdec);
		strcat(destinationATM,atm);
		strcat(destinationATM,indent);
		gpssize = strlen(destinationATM);
		result = f_write(&file1, (const void*)destinationATM, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationATM);

	    // Convert raw data into units of and print it
	    pressureValue = DPG1_GetPressure(PSI, &DPG);
	    whole = pressureValue;
	    not_whole = (pressureValue - whole) * 1000000;

		char snumdpgPSIwhole[5];
		itoa(whole, snumdpgPSIwhole, 10);
		char destinationPSI[] = "Pressure: ";
		char psi[] = " PSI";
		char snumdpgPSIdec[5];
		itoa(not_whole, snumdpgPSIdec, 10);
		strcat(destinationPSI,snumdpgPSIwhole);
		strcat(destinationPSI,dec);
		strcat(destinationPSI,snumdpgPSIdec);
		strcat(destinationPSI,psi);
		strcat(destinationPSI,indent);
		gpssize = strlen(destinationPSI);
		result = f_write(&file1, (const void*)destinationPSI, gpssize, &BytesWr);
		xil_printf("Data: %s\n", destinationPSI);





		result = f_close(&file1);
	    sleep(3);
	}

    cleanup_platform();
    return 0;
}

void GPS_Initialize () {
   TMP3_begin(&TMP, XPAR_PMODTMP3_0_AXI_LITE_IIC_BASEADDR, TMP3_ADDR);
   GPS_begin(&GPS, XPAR_PMODGPS_0_AXI_LITE_GPIO_BASEADDR, XPAR_PMODGPS_0_AXI_LITE_UART_BASEADDR, PERIPHERAL_CLK);
   GPS_setUpdateRate(&GPS, 1000);
   xil_printf("GPS is Initialized.\n\r");
   AQS_begin(&AQS, XPAR_PMODAQS_0_AXI_LITE_IIC_BASEADDR, 0x5B); // Chip address of PmodAQS IIC
   xil_printf("Init AQS Done\n\r");
   DPG1_begin(&DPG, XPAR_PMODDPG1_0_AXI_LITE_SPI_BASEADDR);
   xil_printf("ACL Demo Initializing");
   ACL_begin(&acl, XPAR_PMODACL_0_AXI_LITE_GPIO_BASEADDR,
         XPAR_PMODACL_0_AXI_LITE_SPI_BASEADDR);
   ACL_SetMeasure(&acl, 0);
   ACL_SetGRange(&acl, ACL_PAR_GRANGE_PM4G);
   ACL_SetMeasure(&acl, 1);
   ACL_CalibrateOneAxisGravitational(&acl, ACL_PAR_AXIS_ZP);
   sleep(1);
}

void Get_GPS (char GPS_data[]){
	GPS_getSentence(&GPS, GPS_data);
}

